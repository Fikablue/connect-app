 export const dataUser = [
  {
    fullname: "Rahmat Saudi Al Fathir",
    email: "rahmatsaudi@universitasmulia.ac.id",
    role: "Admin",
    status: "Aktif",
  },
  {
    fullname: "Shafira",
    email: "shafira@universitasmulia.ac.id",
    role: "Employee",
    status: "Aktif",
  },
  {
    fullname: "Lintang",
    email: "lintang@universitasmulia.ac.id",
    role: "Employee",
    status: "Aktif",
  },
  {
    fullname: "Lebah Ganteng",
    email: "lebahganteng@universitasmulia.ac.id",
    role: "Employee",
    status: "Aktif",
  },
];